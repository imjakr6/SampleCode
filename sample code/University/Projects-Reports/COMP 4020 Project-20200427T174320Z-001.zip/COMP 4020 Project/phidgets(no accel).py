from Phidget22.Phidget import *
from Phidget22.Devices.Log import *
from Phidget22.LogLevel import *
from Phidget22.Devices.VoltageInput import *
from Phidget22.Devices.RCServo import *
import random
import time
import threading


# make sensors global so they can interact with other phidgets easily
motor0 = RCServo()
motor1 = RCServo()
soundSensor0 = VoltageInput()
soundSensor1 = VoltageInput()

# this function triggers if 5 seconds have passed without a loud sound reading (currently buggy)
def earsDown():
	if soundSensor0.getVoltage() * 100 < 5: # if sensor detects low sound
		motor0.setTargetPosition(0) #set motors back to 0
		motor1.setTargetPosition(0)
		print("ears down")

# any reading changes to soundSensor0 will trigger the code in this function
def onVoltageChange0(self, voltage):
	print("Voltage 0: " + str(int(voltage * 100))) # times by 100 to output larger integer numbers
	if (voltage * 100) > 10: # if sensor detects sound
		print("ears up")
		# start a 5 second timer
		timer = threading.Timer(5.0, earsDown)
		timer.start()  # after 5 seconds, 'earsDown' will be called

		#move motors up, then move around randomly
		motor0.setTargetPosition(180)
		motor1.setTargetPosition(180)
		motor0.setTargetPosition(random.randint(50, 180))
		motor1.setTargetPosition(random.randint(50, 180))

		#while the sensor detects sound, cancel the timer (currently buggy)
		while (self.getVoltage()) > 5:
			timer.cancel()

# wait 5 seconds after the motor moved up
		# starttime = time.time()
		# while True:
		# 	if (voltage * 100) > 10:
		# 		time.sleep(5.0 - ((time.time() - starttime) % 5.0))
		# 		# after 5 seconds if the last sound voltage wasn't high enough, move the motor back to start position
		# 		if self.getVoltage() * 100 < 10:
		# 			motor0.setTargetPosition(0)
		# 			motor1.setTargetPosition(0)
		# 			break

# any reading changes to soundSensor1 will trigger the code in this function
# def onVoltageChange1(self, voltage):
# 	print("Voltage 1: " + str( int(voltage * 100)))

# attaching soundSensor0 will trigger the code in this function
def onAttachSoundSensor0(self):
	print("Sound Sensor 0 Attached!")

# detaching soundSensor0 will trigger the code in this function
def onDetachSoundSensor0(self):
	print("Sound Sensor 0 Detached!")

# attaching motor0 will trigger the code in this function
def onAttachMotor0(self):
	print("Motor 0 Attached!")

# attaching motor1 will trigger the code in this function
def onAttachMotor1(self):
	print("Motor 1 Attached!")


def main():
	Log.enable(LogLevel.PHIDGET_LOG_INFO, "phidgetlog.log")

	#set up sound sound sensor  in port 0
	soundSensor0.setDeviceSerialNumber(174502)
	soundSensor0.setChannel(0)

	# set up sound sound sensor in port 1
	soundSensor1.setDeviceSerialNumber(174502)
	soundSensor1.setChannel(1)

	#set up motor in port 0
	motor0.setDeviceSerialNumber(169661)
	motor0.setChannel(0)

	# set up motor in port 1
	motor1.setDeviceSerialNumber(169661)
	motor1.setChannel(1)

	# declare function that checks if motor0 and motor1 is attached
	motor0.setOnAttachHandler(onAttachMotor0)
	motor1.setOnAttachHandler(onAttachMotor1)

	# declare function that checks if soundSensor0 is attached and detached
	soundSensor0.setOnAttachHandler(onAttachSoundSensor0)
	soundSensor0.setOnDetachHandler(onDetachSoundSensor0)

	# declare function that constantly checks for voltage changes in soundSensor0 and 1
	soundSensor0.setOnVoltageChangeHandler(onVoltageChange0)
	# soundSensor1.setOnVoltageChangeHandler(onVoltageChange1)


	# waits for soundSensor0 and soundSensor1 to get attached
	soundSensor0.openWaitForAttachment(5000)
	soundSensor1.openWaitForAttachment(5000)

	# waits for motor0 and motor1 to get attached
	motor0.openWaitForAttachment(5000)
	motor1.openWaitForAttachment(5000)

	# adjusts the minimum value needed for for onVoltageChange() to trigger for soundSensor0, lower number is more sensitive
	soundSensor0.setVoltageChangeTrigger(0)

	# move the motors down when the program starts
	motor0.setTargetPosition(0)
	motor0.setEngaged(True)
	motor1.setTargetPosition(0)
	motor1.setEngaged(True)


	try:
		input("Press Enter to Stop\n")
	except (Exception, KeyboardInterrupt):
		pass


	soundSensor0.close()
	soundSensor1.close()
	motor0.close()
	motor1.close()

main()
