from Phidget22.Phidget import *
from Phidget22.Devices.Log import *
from Phidget22.LogLevel import *
from Phidget22.Devices.VoltageInput import *
from Phidget22.Devices.RCServo import *
from Phidget22.Devices.Accelerometer import *
import random
import time
import threading

#Global vars
PETTING_THRESHOLD = 5
TALKING_THRESHOLD = 10
ACCELEROMETER_THRESHOLD = 1

# make sensors global so they can interact with other phidgets easily
motor0 = RCServo()
motor1 = RCServo()
soundSensor0 = VoltageInput()
soundSensor1 = VoltageInput()
accelerometer = Accelerometer()

# this function triggers if 5 seconds have passed without a loud sound reading (currently buggy)
def earsDown():
	if soundSensor0.getVoltage() * 100 < TALKING_THRESHOLD: # if sensor detects low sound set motors back to 0 #DONT NEED THIS CHECK FUNCTION WONT GET CALLED UNLESS VOLTAGE THRESHOLD IS MET
		motor0.setTargetPosition(0)
		motor1.setTargetPosition(0)
		print("ears down")
	else:# set ears up again
		earsUp#ADDED THIS MIGHT FIX BUG?

# any reading changes to soundSensor0 will trigger the code in this function
def earsUp(self, acceleration, voltage):
	print("Acceleration: " + str(acceleration))
	print("Voltage 0: " + str(int(voltage * 100))) # times by 100 to output larger integer numbers
	if (voltage * 100) > TALKING_THRESHOLD: # if sensor detects talking #DONT NEED THIS CHECK FUNCTION WONT GET CALLED UNLESS VOLTAGE THRESHOLD IS MET
		print("ears up")
		# start a 5 second timer
		timer = threading.Timer(5.0, earsDown)
		timer.start()  # after 5 seconds, 'earsDown' will be called

		#move motors up, then move around randomly
		motor0.setTargetPosition(180)
		motor1.setTargetPosition(180)
		motor0.setTargetPosition(random.randint(50, 180))
		motor1.setTargetPosition(random.randint(50, 180))

		#while the sensor detects sound, cancel the timer (currently buggy)
		#while (self.getVoltage()) > 5:
			#timer.cancel()
		#---------------------- DO YOU MEAN IF IT DETECTS SOUND AGAIN RESTART THE TIMER?


def vibrate(self, acceleration, timestamp):
	print("VIBRATE")



# wait 5 seconds after the motor moved up
		# starttime = time.time()
		# while True:
		# 	if (voltage * 100) > 10:
		# 		time.sleep(5.0 - ((time.time() - starttime) % 5.0))
		# 		# after 5 seconds if the last sound voltage wasn't high enough, move the motor back to start position
		# 		if self.getVoltage() * 100 < 10:
		# 			motor0.setTargetPosition(0)
		# 			motor1.setTargetPosition(0)
		# 			break

# any reading changes to soundSensor1 will trigger the code in this function
# def onVoltageChange1(self, voltage):
# 	print("Voltage 1: " + str( int(voltage * 100)))

# attaching/detaching a phidget will acivate these function
def onAttach(self):
	print(str(self) + " Attached!")
def onDetach(self):
	print(str(self) + " Detached!")

def main():
	Log.enable(LogLevel.PHIDGET_LOG_INFO, "phidgetlog.log")

	#set up sound sound sensor  in port 0
	soundSensor0.setDeviceSerialNumber(174502)
	soundSensor0.setChannel(0)

	# set up sound sound sensor in port 1
	soundSensor1.setDeviceSerialNumber(174502)
	soundSensor1.setChannel(1)

	#set up motor in port 0
	motor0.setDeviceSerialNumber(169661)
	motor0.setChannel(0)

	# set up motor in port 1
	motor1.setDeviceSerialNumber(169661)
	motor1.setChannel(1)

	#set up accelerometer
	accelerometer.setDeviceSerialNumber(167856)
	accelerometer.open()

	#call functions when phidgets get attached
	motor0.setOnAttachHandler(onAttach)
	motor1.setOnAttachHandler(onAttach)
	soundSensor0.setOnAttachHandler(onAttach)
	soundSensor1.setOnAttachHandler(onAttach)
	accelerometer.setOnAttachHandler(onAttach)

	#call functions when phidgets get detached
	motor0.setOnDetachHandler(onDetach)
	motor1.setOnDetachHandler(onDetach)
	soundSensor0.setOnDetachHandler(onDetach)
	soundSensor1.setOnDetachHandler(onDetach)
	accelerometer.setOnDetachHandler(onDetach)

	# When voltage changes in  soundSensor0 and 1 call voltage change function
	soundSensor0.setOnVoltageChangeHandler(earsUp)
	soundSensor1.setOnVoltageChangeHandler(vibrate)
	accelerometer.setOnAccelerationChangeHandler(earsUp)

	# adjusts the minimum value needed for for onVoltageChange() to trigger for soundSensor0/soundSensor1, lower number is more sensitive
	soundSensor0.setVoltageChangeTrigger(TALKING_THRESHOLD)
	soundSensor1.setVoltageChangeTrigger(PETTING_THRESHOLD)
	accelerometer.setAccelerationChangeTrigger(ACCELEROMETER_THRESHOLD)

	# waits for soundSensor0 and soundSensor1 to get attached
	soundSensor0.openWaitForAttachment(5000)
	soundSensor1.openWaitForAttachment(5000)

	# waits for motor0 and motor1 to get attached
	motor0.openWaitForAttachment(5000)
	motor1.openWaitForAttachment(5000)

	# waits for accelerometer to get attached
	accelerometer.openWaitForAttachment(1000)

	# move the motors down when the program starts
	motor0.setTargetPosition(0)
	motor0.setEngaged(True)
	motor1.setTargetPosition(0)
	motor1.setEngaged(True)

	#run program untill we press ENTER
	try:
		input("Press Enter to Stop\n")
	except (Exception, KeyboardInterrupt):
		pass


	soundSensor0.close()
	soundSensor1.close()
	motor0.close()
	motor1.close()
	accelerometer.close()
main()
