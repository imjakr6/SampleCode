turboeditor
===========

simple and beatiful android file editor
