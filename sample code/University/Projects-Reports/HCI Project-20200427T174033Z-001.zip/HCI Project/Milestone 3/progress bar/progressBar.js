
function progress() // will probably pass in the canvas to be drawn in so they can be shifted as needed
{
    var c = document.getElementById("progressCanvas");

    var currentDate = new Date();
    drawArc(c, 3/4, currentDate);


    //not sure how were going display the date and switch from day to day here's my thought

    //var currentDate = new Date();
    // var month = currentDate.getUTCMonth() +1;
    // var day = currentDate.getUTCDate();
    // var date = new FT31Date(month, day);
   // drawArc(c, 3/4, date);
}

function drawArc(element, percentage, date)
{

    var ctx = element.getContext("2d");

    var halfWidth = element.width *0.5;
    var halfHeight = element.height * 0.5;
    var thirdHeight = element.height/3;     //used for radius of arc.

    var endPoint =  -Math.PI * (1-percentage); //calculate point on the arc that will be drawn.

    ctx.beginPath();
    ctx.lineWidth = 20;
    ctx.strokeStyle = "#111";
    ctx.arc(halfWidth,halfHeight, thirdHeight, Math.PI, 0);
    ctx.stroke();


    ctx.beginPath();
    ctx.strokeStyle = "#03A9F4";
    ctx.lineWidth = 10;
    ctx.arc(halfWidth, halfHeight, thirdHeight, Math.PI, endPoint);
    ctx.stroke();

    ctx.textAlign="center";
    ctx.font= "15px Arial";

    ctx.fillText(date.toDateString(), halfWidth, halfHeight + 15);

    // ctx.fillText(date.toString(), halfWidth, halfHeight);
}


// function FT31Date(month, day)
// {
//     this.month = month;
//     this.day = day;
//     this.toString = function()
//     {
//         //set up cases to convert the month from number to day
//         return month.toString() + ", " + day.toString();
//     };
// }